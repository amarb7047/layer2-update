const banner = `
███████  █████  ██    ██  █████  ███    ██ 
██      ██   ██ ██    ██ ██   ██ ████   ██ 
███████ ███████ ██    ██ ███████ ██ ██  ██ 
     ██ ██   ██  ██  ██  ██   ██ ██  ██ ██ 
███████ ██   ██   ████   ██   ██ ██   ████
╚══════╝╚══════╝╚═╝  ╚═╝ ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝

    === Running LayerEdge CLI Version ===
** ====================================== **
*    This script is created for free use   *
*  Do not sell or distribute it for profit *
** ====================================== **


* Author: @savanop                       
* Group: https://t.me/savanop121                         
                 `
export default banner;
